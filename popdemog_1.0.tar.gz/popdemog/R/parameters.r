readevopar<-function(demograph_out,
		mode="linear", linear.scale=0.2,log.base=10,
		timeunit="4Ne",
		col.pop="gray45", col.arrow=col.pop,
		length.arrow=0.15, lwd.arrow=1,
		angle.arrow=15,poplab=demograph_out$pop_lab,
		xlim=NULL, ylim=NULL,
		xlab="Population", ylab=paste("Time before present (",timeunit,")", sep=""),
		cex.lab=1, cex.axis=1, axes=T)
{
## three plot modes can be used to adjust the presentation of population size in the plot, the width of each population lineage. mode="linear" gives the proportion of linear.scale to original width; mode="log" gives the logarithms of base log.base of original width, and mode="topology" will treat the width to be zero.
## timeunit gives the unit in the y-axis, has the option of "year", "generation", or with default value as the ms' 4Ne scaled time.

	if(mode!="linear"&&mode!="log"&&mode!="topology")print("Error, you need to redefine the parameter mode");
#re-scale time
		time<-rescalet(demograph_out, timeunit=timeunit);
		if(timeunit!="4Ne"&timeunit!="generation"&timeunit!="year"&timeunit!="kyear"&timeunit!="log10year"){print("Error, you need to redefine the timeunit");}
#color vector
		col.pop.vec<-vector(length=demograph_out$total_pop_num);
		col.arrow.vec<-vector(length=demograph_out$total_pop_num);
		for(i in 1:demograph_out$total_pop_num){
			col.pop.vec[i]=col.pop[(i-1)%%length(col.pop)+1];
			col.arrow.vec[i]=col.arrow[(i-1)%%length(col.arrow)+1];
		}


#plot region

		if(mode=="topology"){
#time_series<-time_series+(1:length(time_series));
			time<-1:length(time);
			plot_N<-0;
		}
		if(is.null(ylim)){
			y_min=min(time);
			y_max=max(time)*1.3;
			ylim=c(y_min-y_max*0.05, y_max);}
		else {ylim=ylim;}


		if(mode=="linear")plot_N<-max(demograph_out$N)*linear.scale;
		if(mode=="log")plot_N<-log(max(demograph_out$N)+1, base=log.base);
		if(is.null(xlim)){
			x_max=max(demograph_out$Pos)+max(plot_N, (max(demograph_out$Pos)-min(demograph_out$Pos))*0.05);
			x_min=min(demograph_out$Pos)-max(plot_N, (max(demograph_out$Pos)-min(demograph_out$Pos))*0.05);
			xlim=c(x_min, x_max);}
		else {xlim=xlim;}

#population labels and positions
		if(length(poplab)==demograph_out$total_pop_num){
			lab.pop<-poplab;
		} else { lab.pop<-1:demograph_out$total_pop_num; }

		lab.pos<-cbind(demograph_out$pop_pos, demograph_out$pop_pos*0-y_max*0.05+y_min);


		list(mode=mode, linear.scale=linear.scale, log.base=log.base, 
				timeunit=timeunit, time=time,
				col.pop=col.pop.vec,col.arrow=col.arrow.vec,
				length.arrow=length.arrow, lwd.arrow=lwd.arrow,
				angle.arrow=angle.arrow,
				lab.pop=lab.pop,lab.pos=lab.pos,
				xlim=xlim, ylim=ylim,
				xlab=xlab,ylab=ylab,
				cex.lab=cex.lab, cex.axis=cex.axis,
				axes=axes)
}


readmigpar<-function(demograph_out, 
		mode="linear", linear.scale=0.2,log.base=10,
		timeunit="4Ne",
		col.pop="gray45", cex.lab=1.5,
		col.arrow="black",length.arrow=0.15, lwd.arrow=1,
		angle.arrow=15, poplab=demograph_out$pop_lab)
{
## three plot modes can be used to adjust the presentation of population size in the plot, the width of each population lineage. mode="linear" gives the proportion of linear.scale to original width; mode="log" gives the logarithms of base log.base of original width, and mode="topology" will treat the width to be zero.
## timeunit gives the unit in the y-axis, has the option of "year", "generation", or with default value as the ms' 4Ne scaled time.
	if(mode!="linear"&&mode!="log"&&mode!="topology")print("Error, you need to redefine the parameter mode");
	if(timeunit!="4Ne"&timeunit!="generation"&timeunit!="year"&timeunit!="kyear"&timeunit!="log10year"){print("Error, you need to redefine the timeunit");}
#re-scale time
	time<-rescalet(demograph_out, timeunit=timeunit);

#color vector
	col.pop.vec<-vector(length=demograph_out$total_pop_num);
	col.arrow.vec<-vector(length=demograph_out$total_pop_num);
	for(i in 1:demograph_out$total_pop_num){
		col.pop.vec[i]=col.pop[(i-1)%%length(col.pop)+1];
		col.arrow.vec[i]=col.arrow[(i-1)%%length(col.arrow)+1];
	}
#migrations 
	events<-1;
	count<-0;                                
	if(length(time)>=2){
		for(i in 2:length(time)){
			if(abs(sum(demograph_out$m[,,i]-demograph_out$m[,,i-1]))>0)events<-c(events, i);
		}
	}
	count<-length(events);
	if(count>=2){
		n<-floor(sqrt(count));
		if(n*n<count & n*(n+1)>=count){mfrow=c(n, n+1);}
		if(n*(n+1)<count & (n+1)*(n+1)>=count){mfrow=c(n+1, n+1);}
		if(n*n==count){mfrow=c(n, n);}
	}
	else {mfrow=c(1, 1);}
#plot region
	xlim=c(-3.5, 3.5); ylim=c(-3.5, 3.5);

#population labels
	if(length(poplab)==demograph_out$total_pop_num){
		lab.pop<-poplab;
	} else { lab.pop<-1:demograph_out$total_pop_num; }


	list(mode=mode, linear.scale=linear.scale, log.base=log.base, 
			timeunit=timeunit, time=time, lab.pop=lab.pop,
			col.pop=col.pop.vec,col.arrow=col.arrow.vec,
			length.arrow=length.arrow, lwd.arrow=lwd.arrow,
			angle.arrow=angle.arrow,
			xlim=xlim, ylim=ylim,
			mfrow=mfrow, events=events,
			cex.lab=cex.lab)
}
readdemograph<-function(inputfile, type, inpos=NULL, N4, gen, poplab)
{
## inputfile is the language file describing the demograph history
## type is the type of language in file, currently support ms, msa, MaCs, and cosi.
## inpos is a vector positions for each population on the plot at time 0.
## N4 is the effective population size of 4Ne, used to rescale the time and geneflow strength


	demograph_out<-list(time_series=c(), Pos=c(), N=c(), m=c(), survive=c(), g_rate=c(), Pos_map=c(), pop_pos=inpos, pop_lab=poplab, ms_cmd=c(), present_pop_num=0, total_pop_num=0, N4=N4, gen=gen);

#translate the coomand to ms languiage
	x<-readcmd(cmdfile=inputfile, type=type, N4=N4);
	demograph_out$ms_cmd<-x$ms_cmd;
	if(is.null(poplab)&type=="cosi")demograph_out$pop_lab=x$pop_lab;
#	L=length(ms_cmd);

#the number of populations for simulation
	x<-readpopnum(demograph_out);
	demograph_out$present_pop_num=x$present_pop_num;
	demograph_out$total_pop_num=x$total_pop_num;


#read the time series
	demograph_out$time_series<-readtime(demograph_out);
	time_num=length(demograph_out$time_series);

	message(paste("There are ",time_num,"time events for ",demograph_out$total_pop_num," populations"));

	x<-readNg(demograph_out);
	demograph_out$N<-x$N;
	demograph_out$g_rate<-x$g_rate;
	message("read N and g, done!");
	demograph_out$m<-readm(demograph_out);
	message("read m, done!");

#population positions
	if(is.null(inpos))demograph_out$pop_pos<-(1:demograph_out$total_pop_num) * max(demograph_out$N, na.rm=T);

#population positions and all
	x<-readpos(demograph_out);
	message("read pos and update, done!");
	demograph_out$time_series<-x$time_series;
	demograph_out$survive<-x$survive;
	demograph_out$Pos<-x$Pos;
	demograph_out$g_rate<-x$g_rate;
	demograph_out$m<-x$m;
	demograph_out$N<-x$N;
	demograph_out$Pos_map<-x$Pos_map;

#update all parameters
	x<-update(demograph_out);
	demograph_out$g_rate<-x$g_rate;
	demograph_out$m<-x$m;
	demograph_out$N<-x$N;


	demograph_out
}
