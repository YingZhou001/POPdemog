cat("macs 2025 15000000 -i 10 -r 3.0e-04 -t 0.00069 -T -I 4 10 1006 1008 1 0
-n 4 0.205 -n 1 58.00274 -n 2 70.041 -n 3 187.55 -eg 0.9e-10 1 482.46
-eg 1.0e-10 2 570.18 -eg 1.1e-10 3 720.23 -em 1.2e-10 1 2 0.731
-em 1.3e-10 2 1 0.731 -em 1.4e-10 3 1 0.2281 -em 1.5e-10 1 3 0.2281
-em 1.6e-10 2 3 0.9094 -em 1.7e-10 3 2 0.9094 -eg 0.007 1 0
-en 0.007001 1 1.98 -eg 0.007002 2 89.7668 -eg 0.007003 3 113.3896
-eG 0.031456 0 -en 0.031457 2 0.1412 -en 0.031458 3 0.07579
-eM 0.031459 0 -ej 0.03146 3 2 -en 0.0314601 2 0.2546
-em 0.0314602 2 1 4.386 -em 0.0314603 1 2 4.386 -eM 0.0697669 0
-ej 0.069767 2 1 -en 0.0697671 1 1.98 -en 0.2025 1 1 -ej 0.9575923 4 1
-em 0.06765 2 4 32 -em 0.06840 2 4 0", file="model-Tennessen.cmd")
#plot the demographic graph
par(mfrow=c(1,2), las=1)
PlotMS(input.file="model-Tennessen.cmd", type="macs", N4=30000, 
       size.scale="log", log.base  =50, inpos=c(1,4,7,9), time.scale="log10year", 
       col.pop=c("brown", "blue", "gold3", "forestgreen"), 
       pops=c("AFR", "EUR", "ASIA", "ARC"), cex.lab=1, cex.axis=1, xlab="", length.arrowtip=0.1)
title("Demographic history")
PlotMS(input.file="model-Tennessen.cmd", type="macs", N4=30000,
       time.scale="log10year", plot.out=F, demo.out=T)->out;
#log10(1000)=3
PlotMig(time_pt=3, time.scale="log10year", demograph_out=out$demograph_out, size.scale="log", log.base=100000,
        mig_par=out$mig_par, col.pop=c("brown", "blue", "gold3", "forestgreen"), xlim=c(0,8), ylim=c(0,10))
legend("topleft", legend=c("AFR", "EUR", "ASIA", "ARC"), 
       col=c("brown", "blue", "gold3", "forestgreen"), pch=20, bty="n")
# title("Migrations 1000 years ago")
print(NOut(time_pt=3, time.scale="log10year", demograph_out=out$demograph_out))
unlink("model-Tennessen.cmd")
